import {Component, Input} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";

export interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'form-example',
  templateUrl: './form-example.component.html',
  styleUrls: ['./form-example.component.scss']
})

export class FormExampleComponent {

  dwellingValues!: FormGroup;

  // dwellingOptions = {
  //   dwellingTypes: ['option1', 'option2', 'option3', 'option4'],
  // };

  constructor(private fb: FormBuilder) {}

  ngOnInit() {
  
    this.dwellingValues = this.fb.group({
      selectControl: new FormControl('All Notifications'),
      inputControl: new FormControl(''),
      textControl: new FormControl(''),
      slideToggleControl: new FormControl(''),
      checkboxControl1: new FormControl(''),
      checkboxControl2: new FormControl(''),
      radioControl: new FormControl(''),
    });

    this.array = [
      {
        icon: 'home',
        value: 'All Notifications',
        disabled: false,
        data: 'All Notification',
        id: "1",
      },
      {
        icon: 'menu',
        value: 'Decoratare',
        disabled: true,
        data: 'Decoratare',
        id: "2",
      },
      {
        icon: 'home',
        value: 'Manage Notifigation',
        disabled: false,
        data: 'Manage Notifigation',
        id: "3",
      },
    ];

    this.selectControl.setValue("Manage Notifigation");
   
  }

  submit() {
    console.log(this.dwellingValues.getRawValue());
  }

  public get selectControl(): FormControl {
    return this.dwellingValues.get('selectControl') as FormControl;
  }
 
  slideToggleControl = new FormControl;
  checkboxControl1 =  new FormControl('', [Validators.required]);
  checkboxControl2 = new FormControl('', [Validators.required]);
  radioControl = new FormControl('', [Validators.required]);
  textControl!: FormControl;
  buttonToggleControl!: FormControl;


  onChange(element : any){
    console.log(element);
  }

  array: any = []

  onSetvalue(){
    
    this.dwellingValues.patchValue({
      inputControl: 'User Name',
      buttonToggleControl : "visibility",
      checkboxControl1: this.checkboxControl1.value,
      checkboxControl2: this.checkboxControl2.value,
      slideToggleControl: this.slideToggleControl.value ? 'on' : 'Off',
    });
   }
 
  onSubmit() {
    this.dwellingValues.getRawValue().selectControl
    console.log(this.dwellingValues.getRawValue()); 
    console.log(this.dwellingValues.getRawValue().selectControl);
    console.log(this.dwellingValues.getRawValue().slideToggleControl);
    console.log(this.dwellingValues.getRawValue().checkboxControl1);
    console.log(this.dwellingValues.getRawValue().checkboxControl2);
  }
}
